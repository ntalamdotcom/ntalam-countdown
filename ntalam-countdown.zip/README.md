# ntalam-countdown
This is my first plugin. It is a simple countdown banner on the top of a website.
